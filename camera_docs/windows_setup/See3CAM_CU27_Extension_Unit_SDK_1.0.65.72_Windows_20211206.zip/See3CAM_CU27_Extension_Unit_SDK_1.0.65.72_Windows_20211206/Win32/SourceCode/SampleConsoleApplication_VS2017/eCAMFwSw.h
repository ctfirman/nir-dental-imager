// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the ECAMFWSW_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// ECAMFWSW_API functions as being imported from a DLL, whereas this DLL sees symbols
// defined with this macro as being exported.
#ifdef ECAMFWSW_EXPORTS
#define ECAMFWSW_API __declspec(dllexport)
#else
#define ECAMFWSW_API __declspec(dllimport)
#endif

BOOL ResetDevice();

BOOL GetDevicesCount(UINT32 *Cnt);

BOOL GetDeviceName(TCHAR *Name);

BOOL GetDevicePath(TCHAR **DevicePaths);

BOOL EnumerateImageDevice(TCHAR *USBInstanceID);

BOOL InitExtensionUnit(TCHAR *USBInstanceID);

BOOL DeinitExtensionUnit();

BOOL ReadFirmwareVersion(UINT8 *pMajorVersion, UINT8 *pMinorVersion1, UINT16 *pMinorVersion2, UINT16 *pMinorVersion3);

BOOL GetCameraUniqueID(TCHAR *szUniqueID);

BOOL GetAWBPresetModeCU27(UINT8 *iAWBPresetMode);

BOOL SetAWBPresetModeCU27(UINT8 iAWBPresetMode);

BOOL GetAWBLockStatusCU27(UINT8 *iAWBLockState);

BOOL SetAWBLockStatusCU27(UINT8 iAWBLockState);

BOOL GetAWBPresetModeCU27(UINT8 *iAWBPresetMode);

BOOL SetAWBPresetModeCU27(UINT8 iAWBPresetMode);

BOOL GetAEMModeCU27(UINT8 *iAEMMode);

BOOL SetAEMModeCU27(UINT8 iAEMMode);

BOOL GetAELockStatusCU27(UINT8 *iAELockMode);

BOOL SetAELockStatusCU27(UINT8 iAELockMode);

BOOL GetFlickerModeCU27(UINT8 *iFlickerMode);

BOOL SetFlickerModeCU27(UINT8 iFlickerMode);

BOOL GetJPEGQvalueCU27(UINT8 *iJPEGQValue);

BOOL SetJPEGQvalueCU27(UINT8 iJPEGQValue);

BOOL RestoreDefaultCU27();

BOOL GetBurstLengthCU27(UINT8 *uBurstLength);

BOOL SetBurstLengthCU27(UINT8 uBurstLength);

BOOL ReadISPFirmwareVersionCU27(UINT8 *pMajorVersion, UINT8 *pMinorVersion1, UINT16 *pMinorVersion2, UINT16 *pMinorVersion3);

BOOL GetDenoiseValueCU27(UINT8 *uDenoiseValue);

BOOL SetDenoiseValueCU27(UINT8 uDenoiseValue);