﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

namespace SampleAppDevicePath
{
    class DShowNativeMethods
    {

        [DllImport("eCAMFwSw.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern bool GetDevicesCount(out int Cnt);

        [DllImport("eCAMFwSw.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern unsafe bool GetDevicePath(char** DevicePath);

        [DllImport("eCAMFwSw.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern unsafe bool GetDeviceName(char* DevicePath);

        [DllImport("eCAMFwSw.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern unsafe bool InitExtensionUnit(char* InstanceID);

        [DllImport("eCAMFwSw.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern bool DeinitExtensionUnit();

        [DllImport("eCAMFwSw.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern bool ReadFirmwareVersion(out int pMajorVersion, out int pMinorVersion1, out int pMinorVersion2, out int pMinorVersion3);

        [DllImport("eCAMFwSw.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern unsafe bool GetCameraUniqueID(char* szUniqueID);

        [DllImport("eCAMFwSw.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern unsafe bool ResetDevice();

        [DllImport("eCAMFwSw.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern unsafe bool GetAWBPresentModeCU27(ref byte iAWBPresentMode);

        [DllImport("eCAMFwSw.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern unsafe bool SetAWBPresentModeCU27(byte iAWBPresentMode);

        [DllImport("eCAMFwSw.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern unsafe bool GetAWBLockStatusCU27(ref byte iAWBLockStatus);

        [DllImport("eCAMFwSw.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern unsafe bool SetAWBLockStatusCU27(byte iAWBLockStatus);

        [DllImport("eCAMFwSw.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern unsafe bool GetAEModeCU27(ref byte iAEMode);

        [DllImport("eCAMFwSw.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern unsafe bool SetAEModeCU27(byte iAEMode);

        [DllImport("eCAMFwSw.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern unsafe bool GetAELockStatusCU27(ref byte iAELockStatus);

        [DllImport("eCAMFwSw.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern unsafe bool SetAELockStatusCU27(byte iAELockStatus);

        [DllImport("eCAMFwSw.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern unsafe bool GetBurstLengthCU27(ref byte iBurstLength);

        [DllImport("eCAMFwSw.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern unsafe bool SetBurstLengthCU27(byte iBurstLength);

        [DllImport("eCAMFwSw.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern unsafe bool GetJPEGQvalueCU27(ref byte iJPEGQvalue);

        [DllImport("eCAMFwSw.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern unsafe bool SetJPEGQvalueCU27(byte iJPEGQvalue);

        [DllImport("eCAMFwSw.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern unsafe bool RestoreDefaultCU27();

        [DllImport("eCAMFwSw.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern unsafe bool GetFlickerModeCU27(ref byte iFlickerMode);

        [DllImport("eCAMFwSw.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern unsafe bool SetFlickerModeCU27(byte iFlickerMode);

        [DllImport("eCAMFwSw.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern unsafe bool GetDenoiseValueCU27(ref byte uDenoiseValue);

        [DllImport("eCAMFwSw.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern unsafe bool SetDenoiseValueCU27(byte uDenoiseValue);

        [DllImport("eCAMFwSw.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern unsafe bool ReadISPFirmwareVersionCU27(out int pMajorVersion, out int pMinorVersion1, out int pMinorVersion2, out int pMinorVersion3);


    }
}
